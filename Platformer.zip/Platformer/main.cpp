#include <SFML/Graphics.hpp>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace sf;
using namespace std;

float lerp(float a, float b, float t) {
	return a + t * (b - a);
}

int main() {
	srand(time(0));

	RenderWindow window(VideoMode(1200, 800), "Simple Platformer");

	Font font;
	if (!font.loadFromFile("arial.ttf")) {
		return -1;
	}

	Text text;
	text.setFont(font);
	text.setCharacterSize(24);
	text.setFillColor(Color::Red);
	text.setPosition(10, 10);

	Texture playerTexture;
	if (!playerTexture.loadFromFile("player.jpg")) {
		return -1;
	}

	Sprite player;
	player.setTexture(playerTexture);
	player.setScale(0.5f, 0.5f);

	RectangleShape sky(Vector2f(1200.0f, 800.0f));
	sky.setFillColor(Color::Cyan);
	sky.setPosition(0, 0);

	vector<RectangleShape> platforms;

	RectangleShape bottomPlatform(Vector2f(1200.0f, 50.0f));
	bottomPlatform.setFillColor(Color::Blue);
	bottomPlatform.setPosition(0, 750);
	platforms.push_back(bottomPlatform);

	// ��������� 5 ����� ��������
	for (int i = 0; i < 5; i++) {
		RectangleShape smallPlatform;
		if (i == 4) {
			smallPlatform.setSize(Vector2f(450.0f, 20.0f));
			smallPlatform.setPosition(375, 375);
		}
		else {
			smallPlatform.setSize(Vector2f(200.0f, 20.0f));

			if (i == 0) smallPlatform.setPosition(0, 575);
			else if (i == 1) smallPlatform.setPosition(1000, 575);
			else if (i == 2) smallPlatform.setPosition(0, 175);
			else if (i == 3) smallPlatform.setPosition(1000, 175);
		}
		smallPlatform.setFillColor(Color::Blue);
		platforms.push_back(smallPlatform);
	}


	float gravity = 0.02;
	bool isJumping = false;
	bool spaceWasPressed = false;

	Vector2f velocity(Vector2f(0, 0));
	float targetY = 750 - player.getGlobalBounds().height;
	float speed = 0.05f;

	Texture coinTexture;
	if (!coinTexture.loadFromFile("coin.jpg")) {
		return -1;
	}

	vector<Sprite> coins;
	for (int i = 0; i < 10; i++) {
		Sprite coin;
		coin.setTexture(coinTexture);
		coin.setScale(0.1f, 0.1f);
		coin.setPosition(rand() % 1200, rand() % 550);
		coins.push_back(coin);
	}


	Clock clock;
	Clock coinClock;
	int coinCount = 0;

	Text timerText;
	timerText.setFont(font);
	timerText.setCharacterSize(24);
	timerText.setFillColor(Color::Red);
	timerText.setPosition(1050, 10);

	Time gameTime = seconds(60);
	Clock gameClock;

	while (window.isOpen()) {
		Event event;
		while (window.pollEvent(event)) {
			if (event.type == Event::Closed)
				window.close();
		}

		if (Keyboard::isKeyPressed(Keyboard::D)) {
			if (player.getPosition().x < 1150)
				player.move(0.5f, 0);
		}

		if (Keyboard::isKeyPressed(Keyboard::A)) {
			if (player.getPosition().x > 0)
				player.move(-0.5f, 0);
		}

		if (Keyboard::isKeyPressed(Keyboard::Space)) {
			if (!isJumping && !spaceWasPressed) {
				isJumping = true;
				velocity.y = -3.5f;
				spaceWasPressed = true;
			}
		}
		else {
			spaceWasPressed = false;
		}

		if (isJumping) {
			velocity.y += gravity;
			if (velocity.y > 0) {
				isJumping = false;
			}
		}

		player.move(0, velocity.y);

		bool isOnPlatform = false;
		for (auto& platform : platforms) {
			if (player.getGlobalBounds().intersects(platform.getGlobalBounds())) {
				isOnPlatform = true;
				if (velocity.y > 0) {
					isJumping = false;
					velocity.y = 0;
					targetY = platform.getPosition().y - player.getGlobalBounds().height;
					player.setPosition(player.getPosition().x, targetY);
				}
				else if (velocity.y < 0) {
					velocity.y = 0;
					player.setPosition(player.getPosition().x, platform.getPosition().y + platform.getGlobalBounds().height);
				}
				else if (velocity.x > 0) {
					player.setPosition(platform.getPosition().x - player.getGlobalBounds().width, player.getPosition().y);
				}
				else if (velocity.x < 0) {
					player.setPosition(platform.getPosition().x + platform.getGlobalBounds().width, player.getPosition().y);
				}
			}
		}
		if (!isOnPlatform) {
			isJumping = true;
		}

		for (auto& coin : coins) {
			if (player.getGlobalBounds().intersects(coin.getGlobalBounds())) {
				coin.setPosition(-100, -100);
				coinCount++;
			}
		}

		if (coinClock.getElapsedTime().asSeconds() >= 1) {
			Sprite coin;
			coin.setTexture(coinTexture);
			coin.setScale(0.1f, 0.1f);
			coin.setPosition(rand() % 1200, rand() % 550);
			coins.push_back(coin);
			coinClock.restart();
		}

		if (gameClock.getElapsedTime() >= gameTime) {
			window.close();

			RenderWindow endWindow(VideoMode(400, 200), "Game Over");
			Text endText;
			endText.setFont(font);
			endText.setCharacterSize(24);
			endText.setFillColor(Color::Red);
			endText.setPosition(50, 50);
			endText.setString("You collected " + to_string(coinCount) + " coins!"); // display the number of coins collected

			while (endWindow.isOpen()) {
				Event endEvent;
				while (endWindow.pollEvent(endEvent)) {
					if (endEvent.type == Event::Closed)
						endWindow.close();
				}

				endWindow.clear();
				endWindow.draw(endText);
				endWindow.display();
			}
		}

		text.setString("Coins: " + to_string(coinCount));
		timerText.setString("Time left: " + to_string(static_cast<int>(gameTime.asSeconds() - gameClock.getElapsedTime().asSeconds()))); // update timer text

		window.clear();
		window.draw(sky);
		for (auto& platform : platforms) {
			window.draw(platform);
		}
		for (auto& coin : coins) {
			window.draw(coin);
		}
		window.draw(player);
		window.draw(text);
		window.draw(timerText);
		window.display();
	}

	return 0;
}
